/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author user
 */
package test;
import model.Patient;
import model.Doctor;
import model.AppointmentManager;
import model.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
public class AppointmentManagerTest {
    @Test
    void shouldScheduleAppointment() {
        AppointmentManager manager =
                new AppointmentManager();
        Patient patient =
                new Patient(
                        "Ali"
                );
        Doctor doctor =
                new Doctor(
                        "Dr Ahmed"
                );
        manager.scheduleAppointment(
                patient,
                doctor
        );
        assertEquals(
                1,
                manager.getAppointments().size()
        );
    }
}
