/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author user
 */
package test;
import model.StudentAgeValidator;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
public class StudentAgeValidatorTest {
    // Positive Test
    @Test
    void shouldAcceptValidAge() {

        StudentAgeValidator validator =
                new StudentAgeValidator();

        assertTrue(
                validator.validateAge(18)
        );

    }

    // Negative Test
    @Test
    void shouldThrowExceptionForNegativeAge() {

        StudentAgeValidator validator =
                new StudentAgeValidator();

        assertThrows(
                IllegalArgumentException.class,
                () -> validator.validateAge(-2)
        );

    }

}