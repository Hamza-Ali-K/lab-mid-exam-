/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.example.labmidexam;

/**
 *
 * @author user
 */
public class LabMidExam {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
