/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author user
 */

package model;

import model.Doctor;
import model.Doctor;
import model.Patient;
import model.Patient;

public class Appointment {

    private Patient patient;
    private Doctor doctor;

    public Appointment(
            Patient patient,
            Doctor doctor) {

        this.patient = patient;
        this.doctor = doctor;

    }

}
