/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author user
 */

package model;
public class Patient {

    private String name;

    public Patient(String name) {

        this.name = name;

    }

    public String getName() {

        return name;

    }

}
