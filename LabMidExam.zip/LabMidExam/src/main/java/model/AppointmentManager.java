/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author user
 */
package model;
import java.util.ArrayList;
import model.Doctor;
import model.Doctor;
import model.Patient;
import model.Patient;
public class AppointmentManager {
    private ArrayList<Appointment>
            appointments =
            new ArrayList<>();
    public void scheduleAppointment(
            Patient patient,
            Doctor doctor) {

        appointments.add(
                new Appointment(
                        patient,
                        doctor
                )
        );

    }
    public ArrayList<Appointment>
    getAppointments() {
        return appointments;
    }

}
